self.__precacheManifest = [
  {
    "revision": "09a0dc5911144539db33bc4783708840",
    "url": "/images/portfolio/selca_logo.png"
  },
  {
    "revision": "fb11a03b7b197f58070d",
    "url": "/js/about.e32946e7.js"
  },
  {
    "revision": "448ce3055a639225761f",
    "url": "/js/app.7c8e9e2a.js"
  },
  {
    "revision": "889da7b8e795cfa604a5",
    "url": "/js/chunk-vendors.784574cb.js"
  },
  {
    "revision": "f50d4e5723813f58b7c8213b65739988",
    "url": "/js/jqplugins.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "0fdd2e219dbb6f5569f210bb6555cbba",
    "url": "/images/portfolio/nrd_logo.png"
  },
  {
    "revision": "4d0140eae3cac32cc9b869cb6956ed8a",
    "url": "/images/portfolio/2vhoxha.jpg"
  },
  {
    "revision": "0695d1ea573c0fda1ad3cba8061c2ec3",
    "url": "/images/portfolio/momenti.jpg"
  },
  {
    "revision": "894e6918aefa35c55506af350c763b26",
    "url": "/images/portfolio/zigzag.jpg"
  },
  {
    "revision": "d3c9a97cdc4b0b233e9dfef4953852b3",
    "url": "/images/portfolio/agrarja.jpg"
  },
  {
    "revision": "ea716f176c657629901dde3452162f7c",
    "url": "/images/portfolio/nrd.jpg"
  },
  {
    "revision": "da4f9cbc97c7141881763bf926416cd3",
    "url": "/images/portfolio/selca.jpg"
  },
  {
    "revision": "f1e4237cc2b4cae8cbc0ae68f549b22e",
    "url": "/images/portfolio/alpha.jpg"
  },
  {
    "revision": "a1b5e00c9bcf9a02885c7befe1816c0c",
    "url": "/images/portfolio/zigzag_logo.png"
  },
  {
    "revision": "7c76612396dd30e6972182e9f0dc0abd",
    "url": "/index.html"
  },
  {
    "revision": "47a40a11211ebeb43d084678ae2537d8",
    "url": "/images/portfolio/agrarja_logo.jpg"
  },
  {
    "revision": "11806c3cf6896ca6ced0e2ead3cfdbfe",
    "url": "/images/r-logo.jpg"
  },
  {
    "revision": "4b8ee22c5844e9cfb043565c166e10ef",
    "url": "/images/portfolio/momenti_logo.jpg"
  },
  {
    "revision": "435cdf047af1a521416dc7d0c9944892",
    "url": "/images/portfolio/uaibo.jpg"
  },
  {
    "revision": "b4a0330233eb34a5887dd2602b8e7e4a",
    "url": "/images/portfolio/2vhoxha_logo.png"
  },
  {
    "revision": "a6587f003811054a5613700a4afc2d9d",
    "url": "/images/portfolio/uaibo_logo.png"
  },
  {
    "revision": "87c131ccf086c36ea8108b7609c16d0f",
    "url": "/images/portfolio/alpha_logo.png"
  },
  {
    "revision": "a567e9c3c154f46cb00d5eb132d6d96a",
    "url": "/images/me.jpg"
  },
  {
    "revision": "5296f9e1e0db6860d19a5b22393e5a09",
    "url": "/images/interests/movies_icon.png"
  },
  {
    "revision": "e6277c5f3934ff474b07a4a96642825c",
    "url": "/images/interests/travel_icon.png"
  },
  {
    "revision": "0018289be3cda303cce6be3b931ec00a",
    "url": "/images/interests/shopping_icon.png"
  },
  {
    "revision": "25f615d3248bb2f01d8f81dfae5780b4",
    "url": "/images/interests/music_icon.png"
  },
  {
    "revision": "331819156f446e9770024ec7dc6363ee",
    "url": "/images/interests/swiming_icon.png"
  },
  {
    "revision": "84beb7d687849d247961470fd3ef05db",
    "url": "/images/loader.gif"
  },
  {
    "revision": "1c057cf91b1bdbf1d1685e6e955a8d29",
    "url": "/css/style3.js"
  },
  {
    "revision": "3d9955b13c9d70acd45da40feeeeca7a",
    "url": "/css/colors/color11-e4c144.css"
  },
  {
    "revision": "6043645c2e2a51edf37bb6979986132f",
    "url": "/favicon.png"
  },
  {
    "revision": "6043645c2e2a51edf37bb6979986132f",
    "url": "/images/favicon.png"
  },
  {
    "revision": "cd45f9bf861e1c54f2487aed130a4256",
    "url": "/images/interests/bicycling_icon.png"
  },
  {
    "revision": "08bd631e92699653229ac599ae3045d3",
    "url": "/images/interests/gaming_icon.png"
  },
  {
    "revision": "f1fa07faa1d6c215cd04e8f8a343de53",
    "url": "/css/responsive.css"
  },
  {
    "revision": "b9230a32ddb5a2d74070a07618afe7d8",
    "url": "/css/colors/light.css"
  },
  {
    "revision": "2d945b3083a0b4a626dbf614a62cb2b4",
    "url": "/css/colors/dark.css"
  },
  {
    "revision": "2ba29d89b90b3f316c8d979e4b55c7dd",
    "url": "/css/colors/color12-5457a6.css"
  },
  {
    "revision": "68c1757f2be4490ada441a51f3aed4ae",
    "url": "/css/colors/color8-00cf95c.css"
  },
  {
    "revision": "47e0463ac199c86d76ce2dd2b130a102",
    "url": "/css/style.css"
  },
  {
    "revision": "859638032220506358b44391f0a3fac5",
    "url": "/css/styleNew.css"
  },
  {
    "revision": "b2fb26f67e86fc377a5c4632dc095525",
    "url": "/cv/CV_Redon_Lacaj_5.pdf"
  },
  {
    "revision": "7ecfba69ea3161195618263616bfe908",
    "url": "/css/colors/color6-ff9999.css"
  },
  {
    "revision": "e6d5bec40d1c50a88f83832739e32891",
    "url": "/css/style2.css"
  },
  {
    "revision": "fb458d9129238513b9d5692a71eb7d4d",
    "url": "/css/stylefonts.css"
  },
  {
    "revision": "7f24199b9010e6c96e93bdd243a363eb",
    "url": "/css/colors/color7-00adb5.css"
  },
  {
    "revision": "f143b61bb720e8e0f0c87ece86bae58c",
    "url": "/css/colors/color9-827055.css"
  },
  {
    "revision": "1ee0139955b29902a768923ec0e8448c",
    "url": "/css/colors/color4-f35b25.css"
  },
  {
    "revision": "3fb37d068871b06d28c6c21b5fe86eb7",
    "url": "/css/colors/color3-2eac6d.css"
  },
  {
    "revision": "59f489cd342e22e1abd1d4507f23ca2e",
    "url": "/css/colors/color5-f6416c.css"
  },
  {
    "revision": "24a53838fd9baf55504a0924e9e32cdd",
    "url": "/css/colors/color2-f23a3a.css"
  },
  {
    "revision": "f52dd035bf5b3e9fa6aa0db2ce80e6fe",
    "url": "/css/colors/color10-8200ff.css"
  },
  {
    "revision": "985f7d00934e395f961188ac00dd4dc5",
    "url": "/css/colors/color1-0487cc.css"
  },
  {
    "revision": "448ce3055a639225761f",
    "url": "/css/app.0a0d11c5.css"
  }
];